"""Alternative word count plugin class for novelibre.

Requires Python 3.7+
Copyright (c) Peter Triesberger
For further information see https://github.com/peter88213/nv_word_counter
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
from pathlib import Path
import webbrowser

import gettext
import locale
import os
import sys

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation(
        'nv_word_counter',
        LOCALE_PATH,
        languages=[CURRENT_LANGUAGE],
    )
    _ = t.gettext
except:

    def _(message):
        return message

import json

from abc import ABC, abstractmethod


class ConfigurationBase(ABC):

    def __init__(self, settings=None, options=None, filePath=None):
        self.settings = None
        self.options = None
        self.filePath = filePath
        self.strLabel = 'SETTINGS'
        self.boolLabel = 'OPTIONS'
        self.set(
            settings=settings,
            options=options,
        )

    @abstractmethod
    def read(self):
        pass

    def set(self, settings=None, options=None):
        self.settings = (settings or {}).copy()
        self.options = (options or {}).copy()

    @abstractmethod
    def write(self):
        pass



class ConfigurationJson(ConfigurationBase):

    def read(self):
        try:
            with open(self.filePath, 'r', encoding='utf-8') as f:
                config = json.load(f)
        except FileNotFoundError:
            config = {}
        if self.strLabel in config:
            section = config[self.strLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if self.boolLabel in config:
            section = config[self.boolLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.get(option, fallback)

    def write(self):
        with open(self.filePath, 'w', encoding='utf-8') as f:
            config = {}
            if self.settings:
                config[self.strLabel] = self.settings
            if self.options:
                config[self.boolLabel] = self.options
            json.dump(
                config,
                f,
                ensure_ascii=False,
                indent=4,
            )
from abc import ABC, abstractmethod
from pathlib import Path



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass

import tkinter as tk


class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def uninstall(self):
        pass

    def _get_icon(self, fileName):
        if self._ctrl.get_preferences().get('large_icons', False):
            size = 24
        else:
            size = 16
        try:
            homeDir = str(Path.home()).replace('\\', '/')
            iconPath = f'{homeDir}/.novx/icons/{size}'
            icon = tk.PhotoImage(file=f'{iconPath}/{fileName}')
        except:
            icon = None
        return icon
import re


class WordCounter:

    IGNORE_PATTERNS = [
        r'\<note\>.*?\<\/note\>',
        r'\<comment\>.*?\<\/comment\>',
        r'\<.+?\>',
    ]

    SEPARATOR_PATTERNS = [
        r'\<\/p\>',
    ]

    def __init__(self):
        self.set_ignore_regex('')
        self.set_separator_regex('—–')

    def set_ignore_regex(self, additionalCharacters):
        self._ignoreRegex = self._get_regex(
            self.IGNORE_PATTERNS[:], additionalCharacters
        )

    def set_separator_regex(self, additionalCharacters):
        self._separatorRegex = self._get_regex(
            self.SEPARATOR_PATTERNS[:], additionalCharacters
        )

    def get_word_count(self, text):
        text = text.replace('\n', '')
        text = self._separatorRegex.sub(' ', text)
        text = self._ignoreRegex.sub('', text)
        return len(text.split())

    def _get_regex(self, patterns, additionalCharacters):
        for s in additionalCharacters:
            patterns.append(re.escape(s))
        return re.compile('|'.join(patterns))



class Plugin(PluginBase):
    VERSION = '0.7.0'
    API_VERSION = '5.50'
    DESCRIPTION = 'Customizable word counter'
    URL = 'https://github.com/peter88213/nv_word_counter'

    HELP_URL = 'https://github.com/peter88213/nv_word_counter/tree/main/docs/nv_word_counter'

    INI_FILENAME = 'wordcounter.json'
    INI_FILEPATH = '.novx/config'
    SETTINGS = dict(
        additional_word_separators=['—', '–'],
        additional_chars_to_ignore=[]
    )
    OPTIONS = {}

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)


        label = _('nv_word_counter Online help')
        self._ui.helpMenu.add_command(
            label=label,
            command=self.open_help,
        )

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/{self.INI_FILEPATH}'
        except:
            configDir = '.'
        self._configuration = ConfigurationJson(
            settings=self.SETTINGS,
            options=self.OPTIONS,
            filePath=f'{configDir}/{self.INI_FILENAME}',
        )
        self._prefs = {}
        self._configuration.read()
        self._prefs.update(self._configuration.settings)
        self._prefs.update(self._configuration.options)

        self._wordCounter = WordCounter()
        self._mdl.nvService.change_word_counter(self._wordCounter)

        self.configure_word_counter()

    def configure_word_counter(self):
        try:
            self._wordCounter.set_ignore_regex(
                self._prefs['additional_chars_to_ignore']
            )
        except AttributeError:
            pass
        try:
            self._wordCounter.set_separator_regex(
                self._prefs['additional_word_separators']
            )
        except AttributeError:
            pass
        self.update_word_count()

    def update_word_count(self):
        if self._mdl.prjFile is None:
            return

        for scId in self._mdl.novel.sections:
            section = self._mdl.novel.sections[scId]
            if section.sectionContent:
                section.wordCount = self._wordCounter.get_word_count(
                    section.sectionContent
                )
        self._mdl.notify_observers()

    def on_quit(self):
        """Write back the configuration file.
        
        Overrides the superclass method.
        """
        for keyword in self._prefs:
            if keyword in self._configuration.options:
                self._configuration.options[keyword] = self._prefs[keyword]
            elif keyword in self._configuration.settings:
                self._configuration.settings[keyword] = self._prefs[keyword]
        self._configuration.write()

    def open_help(self):
        webbrowser.open(self.HELP_URL)

